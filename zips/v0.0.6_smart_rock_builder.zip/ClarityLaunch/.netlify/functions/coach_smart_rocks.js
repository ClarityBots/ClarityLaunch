// coach_smart_rocks.js
const { OpenAI } = require("openai");

const openai = new OpenAI({
  apiKey: process.env.OPENAI_API_KEY,
});

exports.handler = async (event) => {
  try {
    const body = JSON.parse(event.body);
    const { prompt, step, smartData } = body;

    if (step === "summary") {
      const summaryPrompt = `
You are an expert EOS® facilitator. Using the SMART breakdown below, write a concise paragraph summarizing the complete SMART Rock in a way that’s ready to paste into Ninety.io. Avoid listing S-M-A-R-T; instead, consolidate into a natural business sentence.

SMART breakdown:
Specific: ${smartData.specific}
Measurable: ${smartData.measurable}
Achievable: ${smartData.achievable}
Relevant: ${smartData.relevant}
Time-bound: ${smartData["time-bound"]}
      `;

      const summaryCompletion = await openai.chat.completions.create({
        model: "gpt-4",
        messages: [
          { role: "system", content: "You are an EOS facilitator." },
          { role: "user", content: summaryPrompt },
        ],
      });

      const summaryText = summaryCompletion.choices[0].message.content.trim();
      return {
        statusCode: 200,
        body: JSON.stringify({ summary: summaryText }),
      };
    }

    const coachingPrompt = `
You are an EOS® coach helping a client define their SMART Rock. Focus on the "${step}" component. Provide a single refined suggestion in natural language.

User's input: ${prompt}

Respond with a short, practical suggestion for the "${step}" component only. Do not address other SMART letters.
`;

    const response = await openai.chat.completions.create({
      model: "gpt-4",
      messages: [
        { role: "system", content: "You are an EOS SMART Rock coach." },
        { role: "user", content: coachingPrompt },
      ],
    });

    const reply = response.choices[0].message.content.trim();

    return {
      statusCode: 200,
      body: JSON.stringify({ reply }),
    };
  } catch (err) {
    console.error("AI error:", err);
    return {
      statusCode: 500,
      body: JSON.stringify({ error: "An error occurred generating the AI response." }),
    };
  }
};
